import json
import psycopg2
import os
import re
import boto3
import math

def clean_html(value):
    """Función para limpiar etiquetas HTML de un valor."""
    return re.sub(r'<.*?>', '', value) if value else "No disponible"

def get_s3_image_url(course_id, bucket_name):
    """Generar la URL de la imagen desde el bucket de S3."""
    s3_client = boto3.client('s3')
    image_key = f"portada_curso_{course_id}.png"
    
    try:
        s3_client.head_object(Bucket=bucket_name, Key=image_key)
        return f"https://{bucket_name}.s3.amazonaws.com/{image_key}"
    except s3_client.exceptions.ClientError as e:
        # Si no se encuentra la imagen, devolver un valor predeterminado
        print(f"[INFO] Imagen no encontrada para curso {course_id}: {e}")
        return "Imagen no disponible"

def lambda_handler(event, context):
    try:
        # Variables de entorno
        s3_bucket_name = os.environ['S3_BUCKET_NAME']

        # Obtener parámetros de paginación, búsqueda, categoría e idioma desde el evento
        query_params = event.get('queryStringParameters') or {}  # Manejar caso None
        page = int(query_params.get('page', 1))  # Página solicitada, predeterminado: 1
        categoria = query_params.get('categoria', None)  # Filtro de categoría
        busqueda = query_params.get('busqueda', None)  # Filtro de búsqueda en fullname
        idioma = query_params.get('idioma', None)  # Filtro obligatorio por idioma
        page_size = 10  # Tamaño de página fijo: 10 cursos por página

        # Validar que el parámetro `idioma` esté presente y sea válido
        if not idioma or idioma not in ['ES', 'EN', 'PT']:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({
                    'error': "El parámetro 'idioma' es obligatorio y debe ser 'ES', 'EN' o 'PT'."
                })
            }

        # Mapear los valores de idioma a sus equivalentes en base de datos
        idioma_map = {'ES': 1, 'EN': 2, 'PT': 3}
        idioma_id = idioma_map[idioma]

        # Conexión a la base de datos PostgreSQL en AWS
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )

        cursor = conn.cursor()

        # Construir la consulta base con posibles filtros
        base_query = """
            SELECT c.id, c.fullname, c.shortname, c.summary, cat.name AS category_name
            FROM mdl_course c
            LEFT JOIN mdl_course_categories cat ON c.category = cat.id
            INNER JOIN mdl_customfield_data cd ON cd.instanceid = c.id
        """
        where_clauses = ["cd.fieldid = 12 AND cd.intvalue = %s"]  # Filtro obligatorio por idioma
        params = [idioma_id]

        # Agregar filtro por categoría si está presente
        if categoria:
            where_clauses.append("cat.name = %s")
            params.append(categoria)

        # Agregar filtro por búsqueda si está presente
        if busqueda:
            where_clauses.append("c.fullname ILIKE %s")
            params.append(f"%{busqueda}%")

        # Agregar cláusulas WHERE si las hay
        if where_clauses:
            base_query += " WHERE " + " AND ".join(where_clauses)

        # Contar el total de cursos filtrados
        count_query = f"SELECT COUNT(*) FROM ({base_query}) AS filtered_courses"
        cursor.execute(count_query, params)
        total_courses = cursor.fetchone()[0]
        total_pages = math.ceil(total_courses / page_size)

        # Calcular el desplazamiento
        offset = (page - 1) * page_size

        # Agregar orden, límite y desplazamiento a la consulta base
        paginated_query = base_query + " ORDER BY c.id ASC LIMIT %s OFFSET %s"
        params.extend([page_size, offset])
        cursor.execute(paginated_query, params)

        courses = cursor.fetchall()

        # Crear un mapeo de los campos personalizados
        cursor.execute("""
            SELECT cf.id, cf.shortname
            FROM mdl_customfield_field cf
        """)
        customfields = {row[0]: row[1] for row in cursor.fetchall()}

        # Recuperar los datos personalizados relacionados con los cursos
        cursor.execute("""
            SELECT cd.instanceid, cf.shortname, cd.value
            FROM mdl_customfield_data cd
            INNER JOIN mdl_customfield_field cf ON cd.fieldid = cf.id
        """)
        customfield_data = cursor.fetchall()

        # Organizar los datos personalizados por curso
        customfield_mapping = {}
        for instanceid, shortname, value in customfield_data:
            if instanceid not in customfield_mapping:
                customfield_mapping[instanceid] = {}
            customfield_mapping[instanceid][shortname] = value

        # Formatear los datos de los cursos
        catalogo_cursos = []
        for course in courses:
            course_id, fullname, shortname, summary, category_name = course

            # Obtener los valores personalizados
            custom_data = customfield_mapping.get(course_id, {})

            # Obtener la URL de la imagen desde S3
            profile_image = get_s3_image_url(course_id, s3_bucket_name)

            course_data = {
                "profileCodeCurso": shortname,
                "profileNameCurso": fullname,
                "profileDescriptionCurso": summary, #texto enriquecido
                "profileIdCurso": course_id,
                "profileCategoria": category_name,
                "profileCosto": clean_html(custom_data.get("tool_costo", "No disponible")),
                "profileDuracion": clean_html(custom_data.get("tool_duracion", "No disponible")),
                "profileObjetivos": custom_data.get("tool_objetivo", "No disponible"),#texto enriquecido
                "profileObjetosAprendizaje": custom_data.get("tool_objetos", "No disponible"), #texto enriquecido
                "profileTemario": custom_data.get("tool_temario", "No disponible"), #texto enriquecido
                "profileRequerimientosPrevios": custom_data.get("tool_requerimintos_previos", "No disponible"), #texto enriquecido
                "profileRequerimientosEquipo": custom_data.get("tool_requerimientos_equipo", "No disponible"), #texto enriquecido
                "profileCursosRelacionados": custom_data.get("tool_curso_adicional", "No disponible"), #texto enriquecido
                "profileImage": profile_image
            }

            catalogo_cursos.append(course_data)

        # Cerrar la conexión
        cursor.close()
        conn.close()

        # Crear el cuerpo de la respuesta con los datos de los cursos en el formato deseado
        response_body = {
            "catalogo": catalogo_cursos,
            "paginaActual": page,
            "totalPaginas": total_pages,
            "totalCursos": total_courses
        }

        # Crear la respuesta final dejando el objeto JSON directamente en el body
        response = {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps(response_body)
        }

        return response

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': 'Error procesando la solicitud.',
                'details': str(e)
            })
        }
