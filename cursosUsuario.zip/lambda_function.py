import json
import os
import requests
import re

def lambda_handler(event, context):
    try:
        # Recuperar las variables de entorno
        moodle_url = os.environ['MOODLE_URL']
        token = os.environ['MOODLE_TOKEN']

        # Asegurarse de que la URL sea la correcta
        if not moodle_url.endswith('/server.php'):
            moodle_url = f"{moodle_url.rstrip('/')}/webservice/rest/server.php"

        # Validar el body de la solicitud
        body = json.loads(event.get('body', '{}'))
        userid = body.get('userid')

        if not userid:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'El campo userid es obligatorio.'})
            }

        # Configurar los parámetros del request para Moodle
        data = {
            'wstoken': token,
            'wsfunction': 'core_enrol_get_users_courses',
            'moodlewsrestformat': 'json',
            'userid': userid
        }

        # Realizar la solicitud POST al endpoint de Moodle
        response = requests.post(moodle_url, data=data, verify=False, timeout=30)

        # Manejar la respuesta de Moodle
        if response.status_code == 200:
            response_data = response.json()

            if isinstance(response_data, list) and len(response_data) > 0:
                # Formatear los datos de los cursos
                courses = []
                for course in response_data:
                    description = course.get('summary', '')
                    # Eliminar etiquetas HTML de la descripción
                    clean_description = re.sub(r'<.*?>', '', description)
                    formatted_course = {
                        "codeCourse": course.get('shortname'),
                        "nameCourse": course.get('fullname'),
                        "descriptionCourse": clean_description,
                        "categoryid": course.get('category'),
                        "idCourse": course.get('id')
                    }
                    courses.append(formatted_course)

                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json'
                    },
                    'body': json.dumps({"courses": courses})
                }

            return {
                'statusCode': 404,
                'body': json.dumps({'error': 'No se encontraron cursos para el usuario proporcionado.'})
            }

        else:
            return {
                'statusCode': response.status_code,
                'body': response.text
            }

    except requests.exceptions.RequestException as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Error al conectar con Moodle Web Services.', 'details': str(e)})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Error inesperado.', 'details': str(e)})
        }