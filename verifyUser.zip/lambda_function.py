import json
import os
import requests

def lambda_handler(event, context):
    try:
        # Decodificar el cuerpo de la solicitud
        body = json.loads(event.get('body', '{}'))
        email = body.get('email')

        # Validar que el correo electrónico esté presente
        if not email:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': 'El campo email es obligatorio.'})
            }

        # Configuración de la API de Moodle
        moodle_url = os.environ['MOODLE_URL']  # Base URL de tu Moodle
        token = os.environ['MOODLE_TOKEN']    # Token de la API de Moodle
        wsfunction = 'core_user_get_users'    # Función para obtener usuarios
        moodle_ws_url = f"{moodle_url}"

        # Parámetros de la consulta
        params = {
            'wstoken': token,
            'wsfunction': wsfunction,
            'moodlewsrestformat': 'json',
            'criteria[0][key]': 'email',
            'criteria[0][value]': email
        }

        # Hacer la solicitud a la API de Moodle
        response = requests.get(moodle_ws_url, params=params, verify=False)
        response_data = response.json()

        # Validar la respuesta de la API de Moodle
        if 'exception' in response_data:
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Error al consultar la API de Moodle.',
                    'details': response_data.get('message', 'Error desconocido.')
                })
            }

        # Procesar los datos recibidos
        users = response_data.get('users', [])
        if users:
            # Usuario encontrado, regresar el userid
            user = users[0]  # Se asume que el email es único en Moodle
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'message': 'Usuario encontrado.',
                    'userid': user.get('id'),
                    'email': email
                })
            }
        else:
            # No se encontró el usuario
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'message': f'No se encontró ningún usuario con el correo {email}.'
                })
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'error': 'Error procesando la solicitud.',
                'details': str(e)
            })
        }
