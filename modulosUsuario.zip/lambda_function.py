import json
import logging
import os
from psycopg2 import pool

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# -------------------------------------------------------------------------------------
# 1. Inicializar conexión a la base de datos con pooling
# -------------------------------------------------------------------------------------
db_pool = None

def get_db_pool():
    """
    Inicializa y devuelve un pool de conexiones a la base de datos.
    """
    global db_pool
    if db_pool is None:
        import psycopg2
        db_pool = psycopg2.pool.SimpleConnectionPool(
            minconn=1,
            maxconn=5,
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
    return db_pool

class DBManager:
    def __init__(self):
        logger.info("Initializing DBManager")

    def get_connection(self):
        """
        Obtiene una conexión desde el pool.
        """
        try:
            conn = get_db_pool().getconn()
            logger.debug("Database connection acquired from pool")
            return conn
        except Exception as e:
            logger.error("Failed to get database connection: %s", str(e))
            raise

    def release_connection(self, conn):
        """
        Libera la conexión de vuelta al pool.
        """
        try:
            get_db_pool().putconn(conn)
            logger.debug("Database connection released back to pool")
        except Exception as e:
            logger.error("Failed to release database connection: %s", str(e))
            raise

    def get_user_modules(self, user_id):
        """
        Obtiene los módulos del usuario desde la base de datos.
        """
        conn = None
        logger.info("Fetching modules for user_id: %s", user_id)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT modulos FROM mdl_panel_datos WHERE user_id = %s", (user_id,))
                result = cursor.fetchone()
                if result:
                    logger.info("Modules found for user_id %s: %s", user_id, result[0])
                    return result[0]  # Retorna la lista de módulos
                else:
                    logger.info("No modules found for user_id %s", user_id)
                    return []
        except Exception as e:
            logger.error("Error fetching modules for user_id %s: %s", user_id, str(e))
            return []
        finally:
            if conn:
                self.release_connection(conn)

    def get_courses_with_languages(self, course_names):
        """
        Obtiene los cursos desde la base de datos de Moodle junto con su idioma.
        """
        conn = None
        logger.info("Fetching courses and languages from Moodle database for: %s", course_names)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                # Crear la consulta SQL con JOIN a mdl_customfield_data
                query = """
                SELECT 
                    c.id, c.fullname, c.shortname, c.idnumber,
                    COALESCE(cd.intvalue, 1) AS language_code  -- Si no hay idioma, asignamos Español (1)
                FROM mdl_course c
                LEFT JOIN mdl_customfield_data cd 
                    ON cd.instanceid = c.id AND cd.fieldid = 12
                WHERE c.fullname = ANY(%s)
                """
                cursor.execute(query, (course_names,))
                courses = cursor.fetchall()

                # Mapear los valores de idioma
                LANGUAGE_MAP = {1: "Español", 2: "Inglés", 3: "Portugués"}

                # Convertir resultados a diccionarios
                result = [
                    {
                        "id": row[0], 
                        "fullname": row[1], 
                        "shortname": row[2], 
                        "idnumber": row[3], 
                        "language": LANGUAGE_MAP.get(row[4], "Desconocido")  # Si no coincide, asigna "Desconocido"
                    }
                    for row in courses
                ]

                logger.info("Found %d courses in Moodle", len(result))
                return result
        except Exception as e:
            logger.error("Error fetching courses from Moodle database: %s", str(e))
            return []
        finally:
            if conn:
                self.release_connection(conn)

# -------------------------------------------------------------------------------------
# 2. Configuración de los módulos y mapeo de cursos
# -------------------------------------------------------------------------------------
MODULES_COURSE_MAP = {
    "university": "StackUp University",
    "flowlink": "StackUp Flow Link",
    "front2go": "StackUp Front2Go",
    "analytics": "StackUp Business Analytics",
    "pos": "StackUp POS2Go",
    "crm": "StackUp CRM",
    "brandsite": "StackUp Brand Site",
    "revenue": "StackUp Revenue Management",
}

DEFAULT_COURSES = [
    "StackUp University",
    "StackUp Business Analytics",
    "StackUp Panel de control"
]

# -------------------------------------------------------------------------------------
# 3. Lambda Handler
# -------------------------------------------------------------------------------------
db_manager = DBManager()

def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        user_id = body.get('userid')

        if not user_id:
            logger.error("Missing user_id in request")
            return {'statusCode': 400, 'body': json.dumps({"error": "Lambda Handler: user_id es obligatorio."})}

        # Obtener módulos del usuario desde la base de datos
        user_modules = db_manager.get_user_modules(user_id)

        if not user_modules:
            logger.info("No modules found for user_id %s", user_id)
            return {'statusCode': 404, 'body': json.dumps({"error": "No se encontraron módulos para el usuario."})}

        # Determinar cursos a buscar en la base de datos
        courses_to_fetch = DEFAULT_COURSES.copy()  # Incluir los cursos por default

        for module in user_modules:
            if module in MODULES_COURSE_MAP:
                courses_to_fetch.append(MODULES_COURSE_MAP[module])

        logger.info("Final courses to fetch: %s", courses_to_fetch)

        # Obtener información de los cursos desde la base de datos de Moodle
        moodle_courses = db_manager.get_courses_with_languages(courses_to_fetch)

        return {
            'statusCode': 200,
            'body': json.dumps({
                "userid": user_id,
                "modules": user_modules,
                "courses": moodle_courses
            })
        }

    except Exception as e:
        logger.error("Unexpected Error: %s", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({
                "error": "Lambda Handler: Error inesperado.",
                "details": str(e)
            })
        }
