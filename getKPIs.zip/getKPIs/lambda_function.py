import json
import os
import sys
import logging
import decimal
from datetime import datetime
from typing import Any, Dict, List, Tuple

import requests
import psycopg2
import psycopg2.pool
import psycopg2.extras

# Logging Configuration
logger = logging.getLogger()
logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))

for h in list(logger.handlers):
    logger.removeHandler(h)

handler = logging.StreamHandler(sys.stdout)
handler.setLevel(os.getenv("LOG_LEVEL", "INFO"))

formatter = logging.Formatter(
    fmt="%(asctime)s | %(levelname)s | %(module)s:%(lineno)d - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
handler.setFormatter(formatter)
logger.addHandler(handler)

# Environment variables
DB_HOST = os.getenv('DB_HOST')
DB_NAME = os.getenv('DB_NAME')
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
PAGE_SIZE = int(os.getenv('PAGE_SIZE', '500'))
PANEL_URL = os.getenv("URL")

required_env = {'DB_HOST': DB_HOST, 'DB_NAME': DB_NAME, 'DB_USER': DB_USER, 'DB_PASS': DB_PASS, 'PANEL_URL': PANEL_URL}
missing_vars = [key for key, val in required_env.items() if not val]
if missing_vars:
    logger.critical(f"Missing required environment variables: {', '.join(missing_vars)}")
    raise EnvironmentError(f"Missing required environment variables: {', '.join(missing_vars)}")

# Initialize connection pool
pool: psycopg2.pool.SimpleConnectionPool = psycopg2.pool.SimpleConnectionPool(
    minconn=1,
    maxconn=5,
    host=DB_HOST,
    dbname=DB_NAME,
    user=DB_USER,
    password=DB_PASS
)

def authenticate_with_control_panel(headers: Dict[str, str]) -> Any:
    """
    Dependency to authenticate and attach the user to the request.
    Sends the Bearer token to the external validation endpoint.
    """
    logger.info(f"Authenticating with control panel.")
    # Extract the Authorization header
    auth_header = headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return {
            "statusCode": 401,
            "detail": "Missing or invalid Authorization header"
        }

    # Extract the token
    token = auth_header.split("Bearer ")[1]

    user_data = None
    # Validate the token
    if PANEL_URL:
        response = requests.get(
            PANEL_URL + "/auth/validate",
            headers={"Authorization": f"Bearer {token}"}
        )

        if response.status_code != 200:
            return {
                "statusCode": response.status_code,
                "detail": "Invalid token. Access denied."
            }

        # Parse the response JSON
        user_data = response.json()

    # Attach user info to the request state
    logger.info(f"Authenticated user data: {user_data}")

    # Return the user data
    return {
        "statusCode": 200,
        "detail": user_data
    }

def extract_tenant_data(user_data: dict) -> dict:
    """Extracts necessary tenant information from the authenticated user data."""
    tenant_info = user_data.get("tenant", {})
    return {
        "email": user_data.get("email"),
        "tenant_id": tenant_info.get("id"),
        "first_name": tenant_info.get("firstName"),
        "last_name": tenant_info.get("lastName"),
        "company": tenant_info.get("company"),
        "customer_id": tenant_info.get("customerId"),
        "address": tenant_info.get("address"),
        "phone": tenant_info.get("phone"),
        "image": tenant_info.get("logoId"),
        "confirmed": tenant_info.get("confirmed", False),
    }

def custom_json_serializer(obj: Any) -> Any:
    """
    Convert Decimal types to float for JSON serialization.
    Args:
        obj (Any): The object to serialize.
    Returns:
        Any: A JSON-serializable representation.
    Raises:
        TypeError: If the object is not serializable.
    """
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

def validate_dates(start: str, end: str) -> Tuple[datetime, datetime]:
    """
    Validate and convert date strings to datetime objects
    Args:
        start (str): The start date in 'dd/MM/YYYY' format.
        end (str): The end date in 'dd/MM/YYYY' format.
    Returns:
        Tuple[datetime, datetime]: A tuple containing the start and end datetime objects.
    Raises:
        ValueError: If the start date is after the end date.
    """
    start_dt = datetime.strptime(start, '%d/%m/%Y')
    end_dt = datetime.strptime(end, '%d/%m/%Y')
    if start_dt > end_dt:
        raise ValueError("start_date must be on or before end_date")
    return start_dt, end_dt

def fetch_total_records(conn, start_date: str, end_date: str, tenant_id: str) -> int:
    """
    Query the total number of KPI records between two dates
    Args:
        conn: A psycopg2 database connection.
        start_date (str): Start date as string.
        end_date (str): End date as string.
    Returns:
        int: Total number of matching records.
    """
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT COUNT(*)
            FROM kpis
            WHERE id_tenant = %s
              AND TO_TIMESTAMP(fecha_cierre_curso, 'DD/MM/YYYY HH24:MI:SS')
              BETWEEN TO_TIMESTAMP(%s, 'DD/MM/YYYY')
                  AND TO_TIMESTAMP(%s, 'DD/MM/YYYY')
            """,
            (tenant_id, start_date, end_date)
        )
        count = cur.fetchone()[0]
        logger.info(f"Total records: {count}")
        return count

def fetch_page_data(conn, start_date: str, end_date: str, limit: int, offset: int, tenant_id: str) -> List[Dict[str, Any]]:
    """
    Retrieve paginated KPI records filtered by date range.
    Args:
        conn: A psycopg2 database connection.
        start_date (str): Start date string.
        end_date (str): End date string.
        limit (int): Maximum number of records to return.
        offset (int): Record offset for pagination.
    Returns:
        List[Dict[str, Any]]: A list of matching KPI records.
    """
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """
            SELECT *
            FROM kpis
            WHERE id_tenant = %s
              AND TO_TIMESTAMP(fecha_cierre_curso, 'DD/MM/YYYY HH24:MI:SS')
              BETWEEN TO_TIMESTAMP(%s, 'DD/MM/YYYY')
                  AND TO_TIMESTAMP(%s, 'DD/MM/YYYY')
            ORDER BY TO_TIMESTAMP(fecha_cierre_curso, 'DD/MM/YYYY HH24:MI:SS') ASC
            LIMIT %s OFFSET %s
            """,
            (tenant_id, start_date, end_date, limit, offset)
        )
        rows = cur.fetchall()
        logger.info(f"Fetched {len(rows)} records for offset {offset}")
        return rows

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for paginated KPI record retrieval.
    Parses input from the event payload, validates the date range,
    retrieves record count and data, and returns a JSON response.
    Args:
        event (Dict[str, Any]): The Lambda event payload.
        context (Any): Lambda context object.
    Returns:
        Dict[str, Any]: The API Gateway-compatible response.
    """
    logger.info(f"Received event: {event}")
    start_time = datetime.now()
    try:
        user_data = authenticate_with_control_panel(event.get('headers', {}))
        if user_data.get("statusCode") != 200:
            return {'statusCode': 401, 'body': json.dumps({'error': 'Unauthorized'})}

        body = json.loads(event.get('body', '{}'))
        start_date = body.get('start_date')
        end_date = body.get('end_date')
        page = int(body.get('page', 1))
        
        if not start_date or not end_date:
            logger.warning("Missing start_date or end_date")
            return {'statusCode': 400, 'body': json.dumps({'error': 'start_date and end_date are required.'})}
        
        validate_dates(start_date, end_date)

        tenant_data = extract_tenant_data(user_data.get("detail", {}))
        logger.info(f"Request from tenant_id: {tenant_data['tenant_id']}")

        limit = PAGE_SIZE
        offset = (page - 1) * limit

        conn = pool.getconn()
        try:
            total = fetch_total_records(conn, start_date, end_date, tenant_data['tenant_id'])
            total_pages = (total // limit) + (1 if total % limit > 0 else 0)

            if total_pages and page > total_pages:
                logger.warning(f"Page {page} out of range (max {total_pages})")
                return {'statusCode': 400, 'body': json.dumps({'error': 'Page out of range.', 'total_pages': total_pages})}

            data = fetch_page_data(conn, start_date, end_date, limit, offset, tenant_data['tenant_id'])
        finally:
            pool.putconn(conn)

        response = {'page': page, 'total_pages': total_pages, 'limit': limit, 'data': data}
        body_out = json.dumps(response, default=custom_json_serializer)
        logger.info(f"Returning {len(data)} records")
        return {'statusCode': 200, 'body': body_out}

    except ValueError as ve:
        logger.error(f"Validation error: {ve}")
        return {'statusCode': 400, 'body': json.dumps({'error': str(ve)})}
    except psycopg2.Error as db_err:
        logger.exception("Database error")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Database error', 'details': str(db_err)})}
    except Exception as e:
        logger.exception("Unexpected error")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Unexpected error', 'details': str(e)})}
    finally:
        elapsed = (datetime.now() - start_time).total_seconds()
        logger.info(f"Request processed in {elapsed:.3f}s")
