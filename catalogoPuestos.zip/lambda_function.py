import json

def lambda_handler(event, context):
    catalogo_puestos = [
        {"ID": 1, "Puesto": "Gerente General"},
        {"ID": 2, "Puesto": "Contador"},
        {"ID": 3, "Puesto": "Auxiliar de Cuentas por Cobrar"},
        {"ID": 4, "Puesto": "Auxiliar de Costos"},
        {"ID": 5, "Puesto": "Jefe de Venta Directa"},
        {"ID": 6, "Puesto": "Ejecutivo de Venta Directa"},
        {"ID": 7, "Puesto": "Auditor Nocturno"},
        {"ID": 8, "Puesto": "Van Driver"},
        {"ID": 9, "Puesto": "Ama de Llaves"},
        {"ID": 10, "Puesto": "Supervisor de Ama de Llaves"},
        {"ID": 11, "Puesto": "Camarista"},
        {"ID": 12, "Puesto": "Auxiliar de Áreas Públicas"},
        {"ID": 13, "Puesto": "Auxiliar de Lavandería"},
        {"ID": 14, "Puesto": "Jefe de Mantenimiento e Ingeniería"},
        {"ID": 15, "Puesto": "Auxiliar de Mantenimiento e Ingeniería"},
        {"ID": 16, "Puesto": "Gerente de Ventas"},
        {"ID": 17, "Puesto": "Ejecutivo de Ventas"},
        {"ID": 18, "Puesto": "Jefe de Alimentos y Bebidas"},
        {"ID": 19, "Puesto": "Mesero"},
        {"ID": 20, "Puesto": "Capitán"},
        {"ID": 21, "Puesto": "Hostess"},
        {"ID": 22, "Puesto": "Ayudante de Cocina"},
        {"ID": 23, "Puesto": "Cocinero"},
        {"ID": 24, "Puesto": "Ejecutivo de Banquetes"},
        {"ID": 25, "Puesto": "Barman"},
        {"ID": 26, "Puesto": "Ejecutivo de Centros de Consumo / Cajero"},
        {"ID": 27, "Puesto": "Lavaloza"},
        {"ID": 28, "Puesto": "Supervisor de Cocina"},
        {"ID": 29, "Puesto": "Gerente de Restaurante"}
    ]
    
    return {
        "statusCode": 200,
        "body": catalogo_puestos
    }
