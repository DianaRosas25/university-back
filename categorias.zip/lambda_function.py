import json
import requests
import os

def lambda_handler(event, context):
    try:
        # Obtener parámetros desde variables de entorno
        moodle_url = os.getenv('MOODLE_URL')
        moodle_token = os.getenv('MOODLE_TOKEN')
        function_name = "core_course_get_categories"

        # Armar la URL completa
        service_url = f"{moodle_url}/webservice/rest/server.php"

        # Parámetros de la solicitud
        params = {
            "wstoken": moodle_token,
            "wsfunction": function_name,
            "moodlewsrestformat": "json"
        }

        # Hacer la llamada a Moodle
        response = requests.get(service_url, params=params, verify=False, timeout=15)
        response.raise_for_status()  # Verificar errores HTTP

        # Parsear respuesta de Moodle
        categories = response.json()

        # Extraer solo los nombres de las categorías
        category_names = [category.get("name") for category in categories]

        # Formatear respuesta final
        return {
            "statusCode": 200,
            "body": json.dumps({
                "category_names": category_names
            })
        }

    except requests.exceptions.RequestException as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
