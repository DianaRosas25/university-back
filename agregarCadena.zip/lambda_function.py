import json
import os
import psycopg2

def lambda_handler(event, context):
    body = json.loads(event['body'])
    chain_name = body.get('chain_name')
    domain = body.get('domain')

    if not chain_name or not domain:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "chain_name y domain son obligatorios"}),
            "headers": {"Content-Type": "application/json"}
        }

    try:
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            database=os.environ['DB_NAME'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            port=os.environ['DB_PORT']
        )
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO mdl_cadenas_cohortes (chain_name, domain)
            VALUES (%s, %s)
            RETURNING id, chain_name, domain, active, created_at;
        """, (chain_name, domain))

        nueva_cadena = cursor.fetchone()
        conn.commit()

        return {
            "statusCode": 201,
            "body": json.dumps({
                "message": "Cadena agregada correctamente",
                "chain": {
                    "id": nueva_cadena[0],
                    "chain_name": nueva_cadena[1],
                    "domain": nueva_cadena[2],
                    "active": nueva_cadena[3],
                    "created_at": nueva_cadena[4].isoformat()
                }
            }),
            "headers": {"Content-Type": "application/json"}
        }

    except psycopg2.errors.UniqueViolation:
        conn.rollback()
        return {
            "statusCode": 409,
            "body": json.dumps({"error": "Cadena o dominio ya existen"}),
            "headers": {"Content-Type": "application/json"}
        }

    except Exception as e:
        conn.rollback()
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": {"Content-Type": "application/json"}
        }

    finally:
        cursor.close()
        conn.close()
