import json
import os
import random
import string
import logging
from datetime import datetime
import requests
import unicodedata


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def normalize_string(string):
    """Elimina acentos y caracteres especiales, dejando solo letras y números."""
    text = ''.join(
        c for c in unicodedata.normalize('NFKD', string) 
        if unicodedata.category(c) != 'Mn'  # Elimina caracteres diacríticos
    )
    return ''.join(e for e in text if e.isalnum()).lower()

# -------------------------------------------------------------------------------------
# 1. Keep Lazy Loading for psycopg2
# -------------------------------------------------------------------------------------
db_connector = None
def get_db_connector():
    """
    Lazy import for psycopg2 to improve cold-start performance.
    """
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

# -------------------------------------------------------------------------------------
# 2. & 3. Use Global Requests Sessions for MoodleClient
# -------------------------------------------------------------------------------------
# Create global session objects with your custom settings applied once.
# These sessions will persist across invocations in AWS Lambda.

global_moodle_session = requests.Session()
global_moodle_session.mount('https://', requests.adapters.HTTPAdapter(
    max_retries=3,
    pool_connections=10,
    pool_maxsize=10
))


class MoodleClient:
    def __init__(self, token, session=global_moodle_session):
        self.token = token
        self.session = session
        self.base_url = os.environ.get('MOODLE_URL')
        self.endpoint = f"{self.base_url}/webservice/rest/server.php"
        logger.info("MoodleClient initialized with base URL: %s", self.base_url)
        
    def get_user_by_email(self, email):
        logger.debug("Attempting to get user by email: %s", email)
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_get_users',
            'moodlewsrestformat': 'json',
            'criteria[0][key]': 'email',
            'criteria[0][value]': email
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            if response.status_code == 200:
                response_data = response.json()
                if isinstance(response_data, dict) and 'users' in response_data and len(response_data['users']) > 0:
                    logger.info("User found for email: %s", email)
                    return response_data['users'][0]
            logger.warning("No user found for email: %s", email)
            return None
        except Exception as e:
            logger.error("Error getting user by email: %s - %s", email, str(e))
            return None

    def create_user(self, firstname, lastname, email, phone, password):
        logger.info("Creating new user with email: %s", email)
        
        # Normalizar nombres
        sanitized_firstname = normalize_string(firstname)
        sanitized_lastname = normalize_string(lastname)

        # Generar el username
        username = f"{sanitized_firstname[0]}{sanitized_lastname}{''.join(random.choices(string.ascii_lowercase + string.digits, k=5))}"
        
        # Asegurar formato permitido por Moodle
        username = username.replace(" ", "_")
        username = username[:100]
        
        logger.debug("Generated username: %s", username)

        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_create_users',
            'moodlewsrestformat': 'json',
            'users[0][username]': username,
            'users[0][password]': password,
            'users[0][firstname]': firstname,
            'users[0][lastname]': lastname,
            'users[0][email]': email,
            'users[0][phone1]': phone,
            'users[0][auth]': 'manual'
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            logger.info("User creation response status: %d", response.status_code)
            logger.debug("User creation response body: %s", response.text)
            
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if 'exception' in response_data:
                        logger.error("Moodle returned exception while creating user: %s", response_data)
                        return {"error": True, "details": response_data}
                    logger.info("User created successfully with email: %s", email)
                    return {"error": False, "data": response_data}
                except Exception as e:
                    logger.error("Error processing Moodle response: %s", str(e))
                    return {"error": True, "details": {"message": "Error al procesar respuesta de Moodle", "exception": str(e)}}
            logger.error("HTTP error in Moodle service. Status code: %d", response.status_code)
            return {"error": True, "details": {"message": "Error HTTP en el servicio de Moodle", "status_code": response.status_code}}
        except Exception as e:
            logger.error("Error creating user: %s", str(e))
            return {"error": True, "details": {"message": "Error en la creación de usuario", "exception": str(e)}}

    def delete_user(self, user_id):
        logger.info("Attempting to delete user with ID: %s", user_id)
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_delete_users',
            'moodlewsrestformat': 'json',
            'userids[0]': user_id
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            logger.info("Delete user response status: %d", response.status_code)
            logger.debug("Delete user response body: %s", response.text)
            
            if response.status_code == 200:
                logger.info("User %s deleted successfully", user_id)
                return True
            logger.error("Failed to delete user %s", user_id)
            return False
        except Exception as e:
            logger.error("Error deleting user %s: %s", user_id, str(e))
            return False





# -------------------------------------------------------------------------------------
# 4. Database Connection Pooling with psycopg2
# -------------------------------------------------------------------------------------
from psycopg2 import pool

db_pool = None

def get_db_pool():
    """
    Initializes and returns a global connection pool.
    """
    global db_pool
    if db_pool is None:
        psycopg2 = get_db_connector()
        db_pool = psycopg2.pool.SimpleConnectionPool(
            minconn=1,
            maxconn=5,
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
    return db_pool


class DBManager:
    def __init__(self):
        logger.info("Initializing DBManager")

    def get_connection(self):
        """
        Fetch a connection from the pool.
        """
        try:
            conn = get_db_pool().getconn()
            logger.debug("Database connection acquired from pool")
            return conn
        except Exception as e:
            logger.error("Failed to get database connection: %s", str(e))
            raise

    def release_connection(self, conn):
        """
        Release the connection back to the pool.
        """
        try:
            get_db_pool().putconn(conn)
            logger.debug("Database connection released back to pool")
        except Exception as e:
            logger.error("Failed to release database connection: %s", str(e))
            raise

    def is_user_provisioned(self, user_id):
        conn = None
        logger.debug("Checking if user %s is provisioned", user_id)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM mdl_panel_datos WHERE user_id = %s", (user_id,))
                result = cursor.fetchone()[0] > 0
                if result:
                    logger.info("User %s is already provisioned", user_id)
                else:
                    logger.info("User %s is not provisioned", user_id)
                return result
        except Exception as e:
            logger.error("Error checking user provisioning status for user %s: %s", user_id, str(e))
            return False
        finally:
            if conn:
                self.release_connection(conn)

    def get_hotel_by_tenant_id(self, tenant_id):
        conn = self.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT id_hotel, clave, id_marca, id_region 
                    FROM mdl_panel_datos
                    WHERE id_tenant = %s
                    LIMIT 1
                """, (tenant_id,))
                row = cursor.fetchone()
                if row:
                    return {
                        "id_hotel": row[0],
                        "clave": row[1],
                        "id_marca": row[2],
                        "id_region": row[3]
                    }
                return None
        finally:
            self.release_connection(conn)

    def insert_panel_data(self, user_id, tenant_id, hotel_data, modules, role, user_id_panel):
        conn = None
        logger.info("Attempting to insert panel data for user %s, tenant %s", user_id, tenant_id)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                current_date = datetime.now().strftime("%Y-%m-%d")
                cursor.execute("""
                    INSERT INTO mdl_panel_datos 
                    (panel_de_control, id_tenant, id_marca, id_hotel, clave, id_region, user_id, modulos, role, user_id_panel)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s,  %s, %s)
                """, (
                    current_date,
                    tenant_id,
                    hotel_data.get('id_marca'),
                    hotel_data.get('id_hotel'),
                    hotel_data.get('clave'),
                    hotel_data.get('id_region'),
                    user_id,
                    modules,
                    role,
                    user_id_panel
                ))
                conn.commit()
                logger.info("Successfully inserted panel data for user %s", user_id)
                logger.debug("Inserted data: date=%s, tenant=%s, brand=%s, hotel=%s, region=%s", 
                           current_date, tenant_id, hotel_data.get('brand'), 
                           hotel_data.get('id'), hotel_data.get('region'))
                return True
        except Exception as e:
            logger.error("Failed to insert panel data for user %s: %s", user_id, str(e))
            return False
        finally:
            if conn:
                self.release_connection(conn)



# -------------------------------------------------------------------------------------
# Instantiate global clients *once* so they are reused across Lambda invocations
# -------------------------------------------------------------------------------------
moodle_client = MoodleClient(os.environ['MOODLE_TOKEN'])
db_manager = DBManager()

def map_profile_to_role(profile_str):
    """
    Extrae el número del perfil y lo mapea a un rol interno.
    """
    profile_num = profile_str.split('_')[-1]
    if profile_num == '5':
        return 'user'
    elif profile_num == '4':
        return 'admin'
    else:
        return 'unknown'

def generate_random_password(length=12):
    if length < 4:
        raise ValueError("Password length must be at least 4 characters")

    specials = "!@#$%^&*-#"
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits

    # Garantizar al menos un carácter de cada tipo requerido
    password = [
        random.choice(uppercase),
        random.choice(lowercase),
        random.choice(digits),
        random.choice(specials)
    ]

    # Rellenar el resto con una mezcla de todos
    all_chars = lowercase + uppercase + digits + specials
    password += random.choices(all_chars, k=length - 4)

    # Mezclar para que no siempre comiencen igual
    random.shuffle(password)

    return ''.join(password)

def lambda_handler(event, context):
    try:
        logger.info("Evento recibido: %s", json.dumps(event))

        if event.get("detail-type") != "USERCreate":
            logger.warning("Evento ignorado: tipo no válido")
            return {"statusCode": 400, "body": "Evento no válido"}

        user = event["detail"]["data"]
        tenant_id = user.get("tenantId")
        user_panel_id = user.get("id")
        email = user.get("email")
        first_name = user.get("firstName")
        last_name = user.get("lastName")
        phone = user.get("phone")

        # Verificar si ya existe en Moodle
        moodle_user = moodle_client.get_user_by_email(email)
        if moodle_user:
            moodle_user_id = moodle_user["id"]
            logger.info("Usuario %s ya existe en Moodle", email)
            return {"statusCode": 200, "body": "Usuario ya existente"}
        else:
            # Crear usuario
            logger.info("Creando usuario %s en Moodle", email)
            password = generate_random_password()
            response = moodle_client.create_user(
                firstname=first_name,
                lastname=last_name,
                email=email,
                phone=phone,
                password=password
            )

            if response["error"]:
                logger.error("Error creando usuario en Moodle: %s", response["details"])
                return {"statusCode": 500, "body": "Error creando usuario en Moodle"}

            moodle_user_id = response["data"][0]["id"]

        # Obtener hotel del tenant desde tu propia DB o config
        hotel_data = db_manager.get_hotel_by_tenant_id(tenant_id)
        logger.info(hotel_data)
        if not hotel_data:
            logger.error("No se encontró información del hotel para tenant %s", tenant_id)
            moodle_client.delete_user(moodle_user_id)
            return {"statusCode": 500, "body": "Error recuperando info del hotel"}

        # Insertar en BD con módulos vacíos y rol pendiente
        modules = []
        role = "pendiente"

        success = db_manager.insert_panel_data(
            user_id=moodle_user_id,
            tenant_id=tenant_id,
            hotel_data=hotel_data,
            modules=modules,
            role=role,
            user_id_panel=user_panel_id
        )

        if not success:
            logger.error("Error insertando datos en base, eliminando usuario")
            moodle_client.delete_user(moodle_user_id)
            return {"statusCode": 500, "body": "Error insertando en base de datos"}

        logger.info("Usuario %s creado correctamente", email)
        return {"statusCode": 200, "body": "Usuario creado exitosamente"}

    except Exception as e:
        logger.exception("Error inesperado")
        return {"statusCode": 500, "body": f"Error inesperado: {str(e)}"}