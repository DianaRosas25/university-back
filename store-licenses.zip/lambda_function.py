import json
import os
from datetime import datetime, timedelta

# Lazy import
db_connector = None
def get_db_connector():
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        user_id = body.get("UserID")
        tenant_id = body.get("tenantID")
        licenses = body.get("licenses", [])

        if not user_id or not tenant_id or not licenses:
            return response(400, "Faltan campos obligatorios (UserID, tenantID o licenses).")

        psycopg2 = get_db_connector()
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
        cursor = conn.cursor()

        for license in licenses:
            course_id = license.get("courseid")
            quantity = license.get("quantity", 0)

            if not course_id or quantity <= 0:
                return response(400, f"Datos inválidos en licencia: {license}")

            # Validación
            cursor.execute("SELECT 1 FROM mdl_panel_datos WHERE id_tenant = %s AND user_id_panel = %s", (tenant_id, user_id))
            if not cursor.fetchone():
                return response(404, f"Tenant o usuario no encontrados: tenant_id={tenant_id}, user_id={user_id}")

            cursor.execute("SELECT 1 FROM mdl_course WHERE id = %s", (course_id,))
            if not cursor.fetchone():
                return response(404, f"Curso no encontrado: course_id={course_id}")

            # Insertar una fila por licencia
            for _ in range(quantity):
                cursor.execute("""
                    INSERT INTO mdl_tenant_licenses (tenant_id, user_id, course_id, status, created_at)
                    VALUES (%s, %s, %s, %s, %s)
                """, (tenant_id, user_id, course_id, 'active', datetime.utcnow() - timedelta(hours=6)))

        conn.commit()
        cursor.close()
        conn.close()

        return response(200, "Las licencias se han aplicado con éxito")

    except Exception as e:
        return response(500, f"Error interno: {str(e)}")

def response(status_code, message):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "status": str(status_code),
            "message": message
        })
    }
