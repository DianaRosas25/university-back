import json
import os

# Lazy import
db_connector = None
def get_db_connector():
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

def lambda_handler(event, context):
    try:
        query_params = event.get('queryStringParameters') or {}
        user_id = query_params.get("UserID")

        if not user_id:
            return response(400, "El parámetro 'UserID' es obligatorio.")

        psycopg2 = get_db_connector()
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
        cursor = conn.cursor()

        # Obtener tenant_id del usuario
        cursor.execute("""
            SELECT id_tenant 
            FROM mdl_panel_datos 
            WHERE user_id = %s
        """, (user_id,))
        result = cursor.fetchone()

        if not result:
            return response(404, f"No se encontró el usuario con ID: {user_id}")

        tenant_id = result[0]

        # Traer todas las licencias asociadas al usuario y tenant
        cursor.execute("""
            SELECT id, course_id, status 
            FROM mdl_tenant_licenses
            WHERE tenant_id = %s
        """, (tenant_id,))

        rows = cursor.fetchall()
        licenses = []

        for row in rows:
            licenses.append({
                "id": row[0],
                "courseid": row[1],
                "status": row[2]
            })

        cursor.close()
        conn.close()

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "UserID": user_id,
                "tenantID": tenant_id,
                "licenses": licenses
            })
        }

    except Exception as e:
        return response(500, f"Error interno: {str(e)}")

def response(status_code, message):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "status": str(status_code),
            "message": message
        })
    }
