import json
import os
import logging
import requests
from datetime import datetime
import unicodedata
import time
from psycopg2 import pool, extensions

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# -----------------------------------------
# Lazy load psycopg2
# -----------------------------------------
db_connector = None
def get_db_connector():
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

# -----------------------------------------
# Adapter para listas como arrays de texto
# -----------------------------------------
def adapt_list(lst):
    adapted = "ARRAY[" + ",".join("'%s'" % item.replace("'", "''") for item in lst) + "]"
    return extensions.AsIs(adapted)

extensions.register_adapter(list, adapt_list)

# -----------------------------------------
# Global session
# -----------------------------------------
global_moodle_session = requests.Session()
global_moodle_session.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))

# -----------------------------------------
# Application ID -> applicationName fallback
# -----------------------------------------
APPLICATION_ID_MAP = {
    1: "brandsite",
    2: "university",
    3: "flowlink",
    4: "front2go",
    5: "revenue",
    6: "analytics",
    7: "pos",
    8: "crm"
}

# -----------------------------------------
# Role mapper
# -----------------------------------------
def map_profile_to_role(profile_num):
    if profile_num == '5':
        return 'user'
    elif profile_num == '4':
        return 'admin'
    return 'unknown'

# -----------------------------------------
# Moodle Client
# -----------------------------------------
class MoodleClient:
    def __init__(self, token, session=global_moodle_session):
        self.token = token
        self.session = session
        self.base_url = os.environ['MOODLE_URL']
        self.endpoint = f"{self.base_url}/webservice/rest/server.php"

    def get_user_by_email(self, email):
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_get_users',
            'moodlewsrestformat': 'json',
            'criteria[0][key]': 'email',
            'criteria[0][value]': email
        }
        for attempt in range(3):
            try:
                response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
                if response.status_code == 200:
                    data = response.json()
                    if isinstance(data, dict) and data.get('users'):
                        return data['users'][0]
                break
            except Exception as e:
                logger.error("Error getting user by email (attempt %d): %s", attempt + 1, str(e))
                time.sleep(2 ** attempt)
        return None

# -----------------------------------------
# DB Manager
# -----------------------------------------
db_pool = None
def get_db_pool():
    global db_pool
    if db_pool is None:
        psycopg2 = get_db_connector()
        db_pool = psycopg2.pool.SimpleConnectionPool(
            minconn=1,
            maxconn=5,
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
    return db_pool

class DBManager:
    def get_connection(self):
        return get_db_pool().getconn()

    def release_connection(self, conn):
        get_db_pool().putconn(conn)

    def update_role_and_modules(self, user_id_panel, role, modules):
        conn = self.get_connection()
        try:
            with conn.cursor() as cursor:
                time.sleep(1)  # Espera antes de updatear role y módulos
                cursor.execute("""
                    UPDATE mdl_panel_datos
                    SET role = %s,
                        modulos = %s
                    WHERE user_id_panel = %s
                """, (role, modules, user_id_panel))
                conn.commit()
                logger.info("Actualizados role=%s y modulos=%s para user_id_panel=%s", role, modules, user_id_panel)
                return True
        except Exception as e:
            logger.error("Error actualizando rol y módulos: %s", str(e))
            return False
        finally:
            self.release_connection(conn)

# -----------------------------------------
# Global clients
# -----------------------------------------
moodle_client = MoodleClient(os.environ['MOODLE_TOKEN'])
db_manager = DBManager()

# -----------------------------------------
# Lambda handler
# -----------------------------------------
def lambda_handler(event, context):
    try:
        logger.info("Evento recibido: %s", json.dumps(event))

        if event.get("detail-type") != "USER-ROLEUpdate":
            return {"statusCode": 400, "body": "Tipo de evento inválido"}

        detail = event["detail"]
        data = detail["data"]
        tenant_id = data.get("tenantId")
        user_panel_id = data.get("userId")

        modules = []
        role = None

        for key, val in data.items():
            if not key.isdigit():
                continue
            app = val.get("application")
            app_id = val.get("applicationId")

            app_name = None
            if app and isinstance(app, dict):
                app_name = app.get("applicationName")
            if not app_name:
                app_name = APPLICATION_ID_MAP.get(app_id)

            if app_name:
                modules.append(app_name)

            if app_id == 2 and "profile" in val:
                profile_num = val["profile"].split("_")[-1]
                role = map_profile_to_role(profile_num)

        logger.info("Módulos detectados: %s", modules)
        logger.info("Rol detectado: %s", role)

        if not modules:
            logger.warning("No se encontraron módulos para actualizar")
            return {"statusCode": 400, "body": "No hay módulos válidos para actualizar"}

        if not user_panel_id:
            logger.warning("userId (user_panel_id) no proporcionado")
            return {"statusCode": 400, "body": "Falta user_id_panel"}

        success = db_manager.update_role_and_modules(
            user_id_panel=user_panel_id,
            role=role,
            modules=modules
        )

        if not success:
            return {"statusCode": 500, "body": "Error actualizando en base de datos"}

        return {"statusCode": 200, "body": "Actualización de módulos y rol exitosa"}

    except Exception as e:
        logger.exception("Error inesperado")
        return {"statusCode": 500, "body": f"Error inesperado: {str(e)}"}