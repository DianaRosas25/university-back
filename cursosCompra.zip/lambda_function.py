import json
import os
import requests
from datetime import datetime

def lambda_handler(event, context):
    try:
        # Comprobar si el evento tiene un campo 'body' en formato string JSON o si ya es un diccionario
        if 'body' in event and isinstance(event['body'], str):
            body = json.loads(event['body'])
        else:
            body = event

        user_id = body.get('user_id')
        course_name = body.get('course_name')
        idioma = body.get('idioma')  # Campo opcional
        fecha_inicio = body.get('fecha_inicio')

        # Validar campos obligatorios
        if not all([user_id, course_name, fecha_inicio]):
            return {
                'statusCode': 400,
                'body': {
                    'error': 'Faltan campos obligatorios (user_id, course_name, fecha_inicio)'
                }
            }

        # Convertir `fecha_inicio` a formato timestamp UNIX
        try:
            timestart = int(datetime.strptime(fecha_inicio, "%d/%m/%Y").timestamp())
        except ValueError as e:
            return {
                'statusCode': 400,
                'body': {
                    'error': 'Formato de fecha inválido. Use el formato "DD/MM/AAAA".',
                    'details': str(e)
                }
            }

        # Generar el nombre completo del curso si se proporciona idioma
        full_course_name = f"{course_name} {idioma}" if idioma else course_name

        # Configuración de la solicitud a la API de Moodle para buscar el curso
        moodle_url = os.environ['MOODLE_URL']
        token = os.environ['MOODLE_TOKEN']

        if not moodle_url.endswith('/server.php'):
            moodle_url = f"{moodle_url.rstrip('/')}/webservice/rest/server.php"

        # Solicitar la lista de cursos para encontrar el course_id correcto
        course_search_data = {
            'wstoken': token,
            'wsfunction': 'core_course_get_courses',
            'moodlewsrestformat': 'json'
        }

        response = requests.post(moodle_url, data=course_search_data, verify=False, timeout=10)
        if response.status_code != 200:
            return {
                'statusCode': response.status_code,
                'body': {
                    'error': 'Error al llamar a la API de Moodle para obtener los cursos',
                    'details': response.text
                }
            }

        response_data = response.json()
        course_id = None

        # Primero intenta buscar una coincidencia exacta con `full_course_name`
        for course in response_data:
            if course.get('fullname') == full_course_name:
                course_id = course.get('id')
                break

        # Si no encuentra coincidencia exacta, busca coincidencias parciales por `course_name` sin considerar idioma
        if not course_id:
            for course in response_data:
                if course_name in course.get('fullname', ''):
                    course_id = course.get('id')
                    break

        if not course_id:
            return {
                'statusCode': 404,
                'body': {
                    'error': 'Curso no encontrado',
                    'details': f"No se encontró el curso con nombre '{full_course_name}'"
                }
            }

        # Preparar los datos para la matriculación
        enrolment_data = {
            'wstoken': token,
            'wsfunction': 'enrol_manual_enrol_users',
            'moodlewsrestformat': 'json',
            'enrolments[0][roleid]': 5,  # Role ID de estudiante (puede cambiarse si es necesario)
            'enrolments[0][userid]': user_id,
            'enrolments[0][courseid]': course_id,
            'enrolments[0][timestart]': timestart
        }

        # Realizar la solicitud POST para matricular al usuario
        enrol_response = requests.post(moodle_url, data=enrolment_data, verify=False, timeout=10)
        
        if enrol_response.status_code == 200:
            enrol_response_data = enrol_response.json()

            if isinstance(enrol_response_data, dict) and 'exception' in enrol_response_data:
                return {
                    'statusCode': 500,
                    'body': {
                        'error': 'Error al matricular al usuario en Moodle',
                        'details': enrol_response_data.get('message', 'No se proporcionaron detalles del error')
                    }
                }

            return {
                'statusCode': 200,
                'body': {
                    'message': 'Usuario matriculado exitosamente',
                    'course_id': course_id,
                    'course_name': full_course_name,
                    'user_id': user_id,
                    'fecha_inicio': fecha_inicio
                }
            }
        else:
            return {
                'statusCode': enrol_response.status_code,
                'body': {
                    'error': 'Error al llamar a la API de Moodle para matriculación',
                    'details': enrol_response.text
                }
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': {
                'error': 'Error procesando la solicitud.',
                'details': str(e)
            }
        }
