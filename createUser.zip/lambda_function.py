import json
import os
import requests

def lambda_handler(event, context):
    print("Evento: ", event)
    try:
        # Comprobar si el evento tiene un campo 'body' en formato string JSON o si ya es un diccionario
        if 'body' in event and isinstance(event['body'], str):
            # Si el 'body' es una cadena JSON, cargarlo
            body = json.loads(event['body'])
        else:
            # Si el 'body' no existe o ya es un diccionario, asumir que los datos están directamente en el evento
            body = event

        # Extraer la información del cuerpo de la solicitud
        firstname = body.get('firstname')
        lastname = body.get('lastname')
        email = body.get('email')
        phone = body.get('phone')  # Número de teléfono agregado

        # Validar campos obligatorios
        if not all([firstname, lastname, email, phone]):
            return {
                'statusCode': 400,
                'body': {'error': 'Faltan campos obligatorios (firstname, lastname, email, phone)'}
            }

        # Generar el nombre de usuario a partir de la primera letra del nombre y el primer apellido
        username = (firstname[0] + lastname.split()[0]).lower()

        # Configuración de la solicitud a la API de Moodle
        moodle_url = os.environ['MOODLE_URL']
        token = os.environ['MOODLE_TOKEN']
        
        if not moodle_url.endswith('/server.php'):
            moodle_url = f"{moodle_url.rstrip('/')}/webservice/rest/server.php"
        
        # Datos del usuario a enviar
        user_data = {
            'wstoken': token,
            'wsfunction': 'core_user_create_users',
            'moodlewsrestformat': 'json',
            'users[0][username]': username,
            'users[0][createpassword]': 1,  # Generar contraseña y enviar por correo electrónico
            'users[0][firstname]': firstname,
            'users[0][lastname]': lastname,
            'users[0][email]': email,
            'users[0][phone1]': phone,
            'users[0][auth]': 'manual',
        }
        
        print("Creando usuario en Moodle...")
        response = requests.post(moodle_url, data=user_data, verify=False, timeout=10)
        
        if response.status_code == 200:
            response_data = response.json()
            
            # Verificar si la respuesta contiene errores
            if isinstance(response_data, dict) and 'exception' in response_data:
                return {
                    'statusCode': 500,
                    'body': {'error': 'Error al crear el usuario en Moodle', 'details': response_data['message']}
                }
            
            # Devolver la respuesta con el ID del usuario creado
            if isinstance(response_data, list) and len(response_data) > 0:
                return {
                    'statusCode': 201,
                    'body': {'message': 'Usuario creado exitosamente', 'user_id': response_data[0].get('id')}
                }
            else:
                return {
                    'statusCode': 500,
                    'body': {'error': 'Respuesta inesperada de la API de Moodle', 'details': response.text}
                }
        
        else:
            return {
                'statusCode': response.status_code,
                'body': {'error': 'Error al llamar a la API de Moodle', 'details': response.text}
            }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': {'error': 'Error procesando la solicitud.', 'details': str(e)}
        }
