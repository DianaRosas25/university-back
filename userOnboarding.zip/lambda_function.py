import json
import os
import requests
import psycopg2
from datetime import datetime
import random
import string

# Configuración inicial
MOODLE_URL = os.environ['MOODLE_URL']
MOODLE_TOKEN = os.environ['MOODLE_TOKEN']
DB_HOST = os.environ['DB_HOST']
DB_PORT = os.environ['DB_PORT']
DB_USER = os.environ['DB_USER']
DB_PASS = os.environ['DB_PASS']
DB_NAME = os.environ['DB_NAME']

CREATE_USER_ENDPOINT = f"{MOODLE_URL}"
DELETE_USER_ENDPOINT = f"{MOODLE_URL}"

def generate_username(firstname, lastname):
    """Generar un username único."""
    print("[DEBUG] generate_username() invocado")
    print(f"[DEBUG] Parámetros - firstname: {firstname}, lastname: {lastname}")
    base_username = f"{firstname[0].lower()}{lastname.lower()}"
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=5))
    username = f"{base_username}{suffix}"
    print(f"[DEBUG] Username generado: {username}")
    return username

def create_moodle_user(firstname, lastname, email, phone):
    """
    Crear usuario en Moodle.
    Retorna un diccionario con la estructura:
    {"error": False, "data": [...], "username": "..."} o {"error": True, "details": ...}
    """
    print("[INFO] create_moodle_user() invocado")
    print(f"[INFO] Datos de entrada -> firstname: {firstname}, lastname: {lastname}, email: {email}, phone: {phone}")

    username = generate_username(firstname, lastname)
    default_password = f"{username.capitalize()}@123"  # Contraseña predeterminada
    print(f"[DEBUG] Contraseña generada: {default_password} (no la imprimas en producción si es sensible)")

    payload = {
        'wstoken': MOODLE_TOKEN,
        'wsfunction': 'core_user_create_users',
        'moodlewsrestformat': 'json',
        'users[0][username]': username,
        'users[0][password]': default_password,
        'users[0][firstname]': firstname,
        'users[0][lastname]': lastname,
        'users[0][email]': email,
        'users[0][phone1]': phone,
        'users[0][auth]': 'manual'
    }

    print("[DEBUG] Payload para crear usuario en Moodle:", payload)
    print(f"[INFO] Enviando request POST a {CREATE_USER_ENDPOINT} ...")

    try:
        response = requests.post(CREATE_USER_ENDPOINT, data=payload, verify=False, timeout=10)
        print(f"[INFO] Respuesta al crear usuario: {response.status_code} - {response.text}")
        if response.status_code == 200:
            response_data = response.json()
            # Revisar si la respuesta es una lista (éxito) o un dict con errores
            if isinstance(response_data, list):
                print("[DEBUG] Se ha creado el usuario en Moodle correctamente.")
                return {"error": False, "data": response_data, "username": username}
            else:
                print("[ERROR] Respuesta inesperada (no es lista):", response_data)
                return {"error": True, "details": response_data}
        else:
            print("[ERROR] Status code distinto de 200:", response.text)
            return {"error": True, "details": {
                "message": "Error al crear usuario",
                "response": response.text
            }}
    except requests.exceptions.Timeout:
        print("[ERROR] Timeout al crear usuario en Moodle.")
        return {"error": True, "details": {"message": "Timeout al crear usuario en Moodle."}}
    except Exception as e:
        print(f"[ERROR] Excepción inesperada al crear usuario: {str(e)}")
        return {"error": True, "details": {"message": str(e)}}

def delete_moodle_user(user_id):
    """Eliminar usuario en Moodle (core_user_delete_users)."""
    print(f"[INFO] delete_moodle_user() invocado con user_id={user_id}")
    payload = {
        'wstoken': MOODLE_TOKEN,
        'wsfunction': 'core_user_delete_users',
        'moodlewsrestformat': 'json',
        'userids[0]': user_id
    }
    print("[DEBUG] Payload para eliminar usuario:", payload)
    print(f"[INFO] Enviando request POST a {DELETE_USER_ENDPOINT} ...")

    try:
        response = requests.post(DELETE_USER_ENDPOINT, data=payload, verify=False, timeout=10)
        print(f"[INFO] Respuesta al eliminar usuario: {response.status_code} - {response.text}")
        return response.status_code == 200
    except requests.exceptions.Timeout:
        print("[ERROR] Timeout al eliminar usuario en Moodle.")
        return False
    except Exception as e:
        print(f"[ERROR] Excepción inesperada al eliminar usuario: {str(e)}")
        return False

def insert_panel_data(user_id, hotel_id, brand, region, hotel_code, tenant_id):
    """
    Insertar información adicional en la tabla mdl_panel_datos.
    Devuelve True si inserta correctamente, False en caso de error.
    """
    print("[INFO] insert_panel_data() invocado")
    print(f"[DEBUG] Parámetros -> user_id: {user_id}, hotel_id: {hotel_id}, brand: {brand}, region: {region}, hotel_code: {hotel_code}, tenant_id: {tenant_id}")

    try:
        print("[DEBUG] Conectando a la base de datos ...")
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASS,
            dbname=DB_NAME
        )
        cursor = conn.cursor()
        insert_query = """
            INSERT INTO mdl_panel_datos (panel_de_control, id_tenant, id_marca, id_hotel, clave, id_region, user_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        panel_de_control = datetime.now().strftime("%Y-%m-%d")
        data_to_insert = (
            panel_de_control,
            tenant_id,
            brand,
            hotel_id,
            hotel_code,
            region,
            user_id
        )
        print(f"[DEBUG] Ejecutando INSERT con datos: {data_to_insert}")
        cursor.execute(insert_query, data_to_insert)
        conn.commit()
        cursor.close()
        conn.close()
        print("[INFO] Datos insertados correctamente en la base de datos.")
        return True
    except Exception as e:
        print(f"[ERROR] Error al insertar datos en la base de datos: {e}")
        return False

def lambda_handler(event, context):
            # Verifica si el evento es un "ping" de EventBridge
    if event.get('ping') == 'keep-warm':
        print("[INFO] Recibido evento keep-warm")
        return {
            'statusCode': 200,
            'body': json.dumps({"message": "Lambda kept warm"})
        }
    """Handler principal de la Lambda."""
    print("[INFO] >>> Iniciando lambda_handler")
    print(f"[DEBUG] event: {event}")
    print("[DEBUG] Obteniendo body del evento ...")
    body_str = event.get('body', '{}')
    print(f"[DEBUG] body_str: {body_str}")

    try:
        body = json.loads(body_str)
        print(f"[INFO] Body decodificado: {body}")

        required_fields = [
            "firstname", "lastname", "email", "phone",
            "hotelId", "brand", "region", "hotelCode", "tenantId"
        ]
        for field in required_fields:
            if field not in body or not body[field]:
                print(f"[ERROR] Falta el campo obligatorio: {field}")
                return {
                    'statusCode': 400,
                    'body': json.dumps({"error": f"Falta el campo obligatorio: {field}"})
                }

        firstname = body['firstname']
        lastname = body['lastname']
        email = body['email']
        phone = body['phone']
        hotel_id = body['hotelId']
        brand = body['brand']
        region = body['region']
        hotel_code = body['hotelCode']
        tenant_id = body['tenantId']

        # Crear usuario en Moodle
        print("[INFO] Llamando a create_moodle_user() ...")
        moodle_response = create_moodle_user(firstname, lastname, email, phone)

        if moodle_response["error"]:
            print("[ERROR] Error al crear usuario en Moodle:", moodle_response["details"])
            return {
                'statusCode': 400,
                'body': json.dumps(moodle_response["details"])
            }

        # Extraer el ID del usuario creado
        moodle_user_id = moodle_response["data"][0].get('id')
        username = moodle_response["username"]
        print(f"[INFO] Usuario creado en Moodle con ID: {moodle_user_id} y username: {username}")

        # Insertar datos adicionales en la BD
        print("[INFO] Llamando a insert_panel_data() ...")
        if not insert_panel_data(moodle_user_id, hotel_id, brand, region, hotel_code, tenant_id):
            # Si falla la inserción, eliminamos al usuario para no dejar cuentas huérfanas
            print("[ERROR] Falló la inserción en la BD. Eliminando usuario en Moodle ...")
            delete_moodle_user(moodle_user_id)
            return {
                'statusCode': 500,
                'body': json.dumps({"error": "Error al insertar datos en la base de datos. Usuario eliminado."})
            }

        print("[INFO] Proceso finalizado exitosamente.")
        return {
            'statusCode': 201,
            'body': json.dumps({"message": f"Usuario: {username} y datos registrados exitosamente."})
        }

    except Exception as e:
        print(f"[ERROR] Excepción inesperada en lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({"error": "Error inesperado.", "details": str(e)})
        }

