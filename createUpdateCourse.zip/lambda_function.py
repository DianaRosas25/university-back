import json
import os
import requests

def lambda_handler(event, context):
    print(event)
    print(context)
    try:
        moodle_url = os.environ['MOODLE_URL']
        token = os.environ['MOODLE_TOKEN']

        if not moodle_url.endswith('/server.php'):
            moodle_url = f"{moodle_url.rstrip('/')}/webservice/rest/server.php"

        # Validar queryStringParameters
        query_params = event.get('queryStringParameters', {})
        print("Query params recibidos:", query_params)

        course_id = query_params.get('idCourse')
        if not course_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Falta el campo obligatorio idCourse'})
            }

        data = {
            'wstoken': token,
            'wsfunction': 'core_course_get_courses',
            'moodlewsrestformat': 'json',
            'options[ids][0]': course_id
        }

        response = requests.post(moodle_url, data=data, verify=False, timeout=30)

        if response.status_code == 200:
            response_data = response.json()

            if isinstance(response_data, list) and len(response_data) > 0:
                course_info = response_data[0]
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        "codeCourse": course_info.get('shortname'),
                        "nameCourse": course_info.get('fullname'),
                        "descriptionCourse": course_info.get('summary'),
                        "categoryid": course_info.get('categoryid'),
                        "idCourse": course_info.get('id')
                    })
                }

        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Curso no encontrado', 'details': response.text})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Error procesando la solicitud.', 'details': str(e)})
        }
