import json
import requests
import os
from datetime import datetime
import random
import logging
import string
import unicodedata

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def normalize_string(string):
    """Elimina acentos y caracteres especiales, dejando solo letras y números."""
    text = ''.join(
        c for c in unicodedata.normalize('NFKD', string) 
        if unicodedata.category(c) != 'Mn'  # Elimina caracteres diacríticos
    )
    return ''.join(e for e in text if e.isalnum()).lower()

# -------------------------------------------------------------------------------------
# 1. Keep Lazy Loading for psycopg2
# -------------------------------------------------------------------------------------
db_connector = None
def get_db_connector():
    """
    Lazy import for psycopg2 to improve cold-start performance.
    """
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

# -------------------------------------------------------------------------------------
# 2. & 3. Use Global Requests Sessions for APIClient and MoodleClient
# -------------------------------------------------------------------------------------
# Create global session objects with your custom settings applied once.
# These sessions will persist across invocations in AWS Lambda.
global_api_session = requests.Session()
global_api_session.mount('https://', requests.adapters.HTTPAdapter(
    max_retries=3,
    pool_connections=10,
    pool_maxsize=10
))

global_moodle_session = requests.Session()
global_moodle_session.mount('https://', requests.adapters.HTTPAdapter(
    max_retries=3,
    pool_connections=10,
    pool_maxsize=10
))

class APIClient:
    def __init__(self, session=global_api_session):
        self.bearer_token = None
        self.refresh_token = None
        self.session = session
        
        self.base_url = os.environ.get('URL')
        self.login_endpoint = f"{self.base_url}/auth/login"
        self.validate_endpoint = f"{self.base_url}/auth/validate"
        self.logout_endpoint = f"{self.base_url}/auth/logout"
        self.hotels_endpoint_template = f"{self.base_url}/hotels?tenantId={{tenantId}}"
        logger.info("APIClient initialized with base URL: %s", self.base_url)
    
    def login(self, username, password):
        try:
            login_payload = {"email": username, "password": password}
            response = self.session.post(
                self.login_endpoint,
                json=login_payload,
                timeout=3
            )
            if response.status_code == 201:
                data = response.json()
                if data.get('message') == "LOGIN_SUCCESS":
                    self.bearer_token = data['token']
                    self.refresh_token = data['refreshToken']
                    logger.info("API Client: Session started successfully")
                    return True
            logger.error("API Client: Login failed. Status Code: %d", response.status_code)
            return False
        except Exception as e:
            logger.error("API Client: Login error: %s", str(e))
            return False

    def validate_session(self):
        logger.debug("Validating session")
        return self.make_request(self.validate_endpoint)

    def get_hotels(self, tenant_id):
        logger.debug("Getting hotels for tenant ID: %s", tenant_id)
        return self.make_request(self.hotels_endpoint_template.format(tenantId=tenant_id))

    def logout(self):
        try:
            response = self.make_request(self.logout_endpoint)
            if response.status_code == 200:
                logger.info("API Client: Logout successful")
                return True
            logger.error("API Client: Logout error. Status Code: %d", response.status_code)
            return False
        except Exception as e:
            logger.error("API Client: Logout error: %s", str(e))
            return False

    def make_request(self, url, method='get'):
        headers = {'Authorization': f'Bearer {self.bearer_token}'}
        response = self.session.request(method, url, headers=headers, timeout=5)
        logger.info("Request to %s completed with status code: %d", url, response.status_code)
        return response



class MoodleClient:
    def __init__(self, token, session=global_moodle_session):
        self.token = token
        self.session = session
        self.base_url = os.environ.get('MOODLE_URL')
        self.endpoint = f"{self.base_url}/webservice/rest/server.php"
        logger.info("MoodleClient initialized with base URL: %s", self.base_url)
        
    def get_user_by_email(self, email):
        logger.debug("Attempting to get user by email: %s", email)
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_get_users',
            'moodlewsrestformat': 'json',
            'criteria[0][key]': 'email',
            'criteria[0][value]': email
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            if response.status_code == 200:
                response_data = response.json()
                if isinstance(response_data, dict) and 'users' in response_data and len(response_data['users']) > 0:
                    logger.info("User found for email: %s", email)
                    return response_data['users'][0]
            logger.warning("No user found for email: %s", email)
            return None
        except Exception as e:
            logger.error("Error getting user by email: %s - %s", email, str(e))
            return None

    def create_user(self, firstname, lastname, email, phone, password):
        logger.info("Creating new user with email: %s", email)
        
        # Normalizar nombres
        sanitized_firstname = normalize_string(firstname)
        sanitized_lastname = normalize_string(lastname)

        # Generar el username
        username = f"{sanitized_firstname[0]}{sanitized_lastname}{''.join(random.choices(string.ascii_lowercase + string.digits, k=5))}"
        
        # Asegurar formato permitido por Moodle
        username = username.replace(" ", "_")
        username = username[:100]
        
        logger.debug("Generated username: %s", username)

        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_create_users',
            'moodlewsrestformat': 'json',
            'users[0][username]': username,
            'users[0][password]': password,
            'users[0][firstname]': firstname,
            'users[0][lastname]': lastname,
            'users[0][email]': email,
            'users[0][phone1]': phone,
            'users[0][auth]': 'manual'
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            logger.info("User creation response status: %d", response.status_code)
            logger.debug("User creation response body: %s", response.text)
            
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if 'exception' in response_data:
                        logger.error("Moodle returned exception while creating user: %s", response_data)
                        return {"error": True, "details": response_data}
                    logger.info("User created successfully with email: %s", email)
                    return {"error": False, "data": response_data}
                except Exception as e:
                    logger.error("Error processing Moodle response: %s", str(e))
                    return {"error": True, "details": {"message": "Error al procesar respuesta de Moodle", "exception": str(e)}}
            logger.error("HTTP error in Moodle service. Status code: %d", response.status_code)
            return {"error": True, "details": {"message": "Error HTTP en el servicio de Moodle", "status_code": response.status_code}}
        except Exception as e:
            logger.error("Error creating user: %s", str(e))
            return {"error": True, "details": {"message": "Error en la creación de usuario", "exception": str(e)}}

    def delete_user(self, user_id):
        logger.info("Attempting to delete user with ID: %s", user_id)
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_delete_users',
            'moodlewsrestformat': 'json',
            'userids[0]': user_id
        }
        try:
            response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
            logger.info("Delete user response status: %d", response.status_code)
            logger.debug("Delete user response body: %s", response.text)
            
            if response.status_code == 200:
                logger.info("User %s deleted successfully", user_id)
                return True
            logger.error("Failed to delete user %s", user_id)
            return False
        except Exception as e:
            logger.error("Error deleting user %s: %s", user_id, str(e))
            return False





# -------------------------------------------------------------------------------------
# 4. Database Connection Pooling with psycopg2
# -------------------------------------------------------------------------------------
from psycopg2 import pool

db_pool = None

def get_db_pool():
    """
    Initializes and returns a global connection pool.
    """
    global db_pool
    if db_pool is None:
        psycopg2 = get_db_connector()
        db_pool = psycopg2.pool.SimpleConnectionPool(
            minconn=1,
            maxconn=5,
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
    return db_pool


class DBManager:
    def __init__(self):
        logger.info("Initializing DBManager")

    def get_connection(self):
        """
        Fetch a connection from the pool.
        """
        try:
            conn = get_db_pool().getconn()
            logger.debug("Database connection acquired from pool")
            return conn
        except Exception as e:
            logger.error("Failed to get database connection: %s", str(e))
            raise

    def release_connection(self, conn):
        """
        Release the connection back to the pool.
        """
        try:
            get_db_pool().putconn(conn)
            logger.debug("Database connection released back to pool")
        except Exception as e:
            logger.error("Failed to release database connection: %s", str(e))
            raise

    def is_user_provisioned(self, user_id):
        conn = None
        logger.debug("Checking if user %s is provisioned", user_id)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM mdl_panel_datos WHERE user_id = %s", (user_id,))
                result = cursor.fetchone()[0] > 0
                if result:
                    logger.info("User %s is already provisioned", user_id)
                else:
                    logger.info("User %s is not provisioned", user_id)
                return result
        except Exception as e:
            logger.error("Error checking user provisioning status for user %s: %s", user_id, str(e))
            return False
        finally:
            if conn:
                self.release_connection(conn)

    def insert_panel_data(self, user_id, tenant_id, hotel_data, modules, role, user_id_panel):
        conn = None
        logger.info("Attempting to insert panel data for user %s, tenant %s", user_id, tenant_id)
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                current_date = datetime.now().strftime("%Y-%m-%d")
                cursor.execute("""
                    INSERT INTO mdl_panel_datos 
                    (panel_de_control, id_tenant, id_marca, id_hotel, clave, id_region, user_id, modulos, role, user_id_panel)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s,  %s, %s)
                """, (
                    current_date,
                    tenant_id,
                    hotel_data.get('brand'),
                    hotel_data.get('id'),
                    hotel_data.get('code'),
                    hotel_data.get('region'),
                    user_id,
                    modules,
                    role,
                    user_id_panel
                ))
                conn.commit()
                logger.info("Successfully inserted panel data for user %s", user_id)
                logger.debug("Inserted data: date=%s, tenant=%s, brand=%s, hotel=%s, region=%s", 
                           current_date, tenant_id, hotel_data.get('brand'), 
                           hotel_data.get('id'), hotel_data.get('region'))
                return True
        except Exception as e:
            logger.error("Failed to insert panel data for user %s: %s", user_id, str(e))
            return False
        finally:
            if conn:
                self.release_connection(conn)
    
    



# -------------------------------------------------------------------------------------
# Instantiate global clients *once* so they are reused across Lambda invocations
# -------------------------------------------------------------------------------------
api_client = APIClient()
moodle_client = MoodleClient(os.environ['MOODLE_TOKEN'])
db_manager = DBManager()

def map_profile_to_role(profile_num):
    if profile_num == '5':
        return 'user'
    elif profile_num == '4':
        return 'admin'
    else:
        return 'unknown'  # o podrías manejar un error



def lambda_handler(event, context):
        # Verifica si el evento es un "ping" de EventBridge
    if event.get('ping') == 'keep-warm':
        logger.info("Received keep-warm event")
        return {
            'statusCode': 200,
            'body': json.dumps({"message": "Lambda kept warm"})
        }

    try:
        logger.info("Processing new request")
        body = json.loads(event.get('body', '{}'))
        username = body.get('username')
        password = body.get('password')
        password = password + "*"

        if not all([username, password]):
            logger.error("Missing username or password")
            return {'statusCode': 400, 'body': json.dumps({"error": "Lambda Handler: Faltan el nombre de usuario o la contraseña."})}

        logger.info("Attempting to login user: %s", username)
        if not api_client.login(username, password):
            logger.error("Failed to authenticate user: %s", username)
            return {'statusCode': 401, 'body': json.dumps({"error": "Lambda Handler: No se pudo autenticar el usuario."})}

        logger.info("Validating user session")
        validate_response = api_client.validate_session()
        if validate_response.status_code != 200:
            logger.error("Failed to validate user session. Status code: %d", validate_response.status_code)
            return {'statusCode': 500, 'body': json.dumps({"error": "Lambda Handler: Error al validar el usuario."})}
        
        user_data = validate_response.json()
        logger.info("User session validated successfully")
        
        # Validar acceso a University
        tenant_applications = user_data.get('tenant', {}).get('tenantApplications', [])
        modules = [str(app.get('application').get('applicationName')) for app in tenant_applications]
        university_app = next((app for app in tenant_applications if app.get('applicationId') == 2), None)
        if not university_app:
            logger.error("User does not have access to University application")
            api_client.logout()
            return {'statusCode': 403, 'body': json.dumps({"error": "Lambda Handler: El usuario no tiene acceso a la aplicación University."})}

        user_applications = user_data.get('userApplications', [])
        university_app2 = next(
            (app for app in user_applications if app['application']['applicationName'] == 'university'), None
        )

        if not university_app2 or 'profile' not in university_app2:
            logger.error("Usuario no tiene perfil asignado para University.")
            api_client.logout()
            return {'statusCode': 403, 'body': json.dumps({"error": "Usuario no tiene perfil asignado para University."})}

        profile_str = university_app2['profile']  # Ej: "LMS_Perfil_5"
        profile_num = profile_str.split('_')[-1]  # "5"

        tenant_id = user_data['tenant']['id']
        email = user_data['tenant']['email']
        phone = user_data['tenant']['phone']
        firstname = user_data['tenant']['firstName']
        lastname = user_data['tenant']['lastName']
        
        logger.info("Processing user data - Email: %s, TenantID: %s", email, tenant_id)

        # Verificar/crear usuario en Moodle
        logger.info("Checking if user exists in Moodle")
        moodle_user = moodle_client.get_user_by_email(email)
        if moodle_user:
            logger.info("User found in Moodle with ID: %s", moodle_user['id'])
            moodle_user_id = moodle_user['id']
        else:
            logger.info("Creating new user in Moodle")
            moodle_response = moodle_client.create_user(firstname, lastname, email, phone, password)
            if moodle_response["error"]:
                logger.error("Failed to create Moodle user: %s", moodle_response["details"])
                api_client.logout()
                return {
                    'statusCode': 400,
                    'body': json.dumps({
                        "error": "Lambda Handler: Error al crear usuario en Moodle",
                        "details": moodle_response["details"]
                    })
                }
            moodle_user_id = moodle_response["data"][0].get('id')
            logger.info("User created in Moodle with ID: %s", moodle_user_id)
        
        role = map_profile_to_role(profile_num)

        # Verificar aprovisionamiento
        logger.info("Checking if user is already provisioned")
        if db_manager.is_user_provisioned(moodle_user_id):
            logger.info("User is already provisioned")
            api_client.logout()
            return {'statusCode': 200, 'body': json.dumps({"message": "Lambda Handler: El usuario ya está aprovisionado."})}

        # Obtener datos del hotel
        logger.info("Fetching hotel data for tenant: %s", tenant_id)
        hotels_response = api_client.get_hotels(tenant_id)
        if hotels_response.status_code != 200:
            logger.error("Failed to fetch hotel data. Status code: %d", hotels_response.status_code)
            api_client.logout()
            return {'statusCode': 500, 'body': json.dumps({"error": "Lambda Handler: No se pudo obtener información del hotel."})}
        
        hotels_data = hotels_response.json()
        hotel = hotels_data['data'][0] if hotels_data.get('data') else None
        logger.info("Hotel data retrieved successfully")

        user_id_panel = user_data.get('id')

        # Insertar datos
        logger.info("Inserting panel data for user: %s", moodle_user_id)
        if not db_manager.insert_panel_data(moodle_user_id, tenant_id, hotel, modules, role, user_id_panel):
            logger.error("Failed to insert panel data. Deleting Moodle user")
            moodle_client.delete_user(moodle_user_id)
            api_client.logout()
            return {
                'statusCode': 500,
                'body': json.dumps({"error": "Lambda Handler: Error al insertar datos en la base de datos. Usuario eliminado."})
            }

        logger.info("User provisioning completed successfully")
        api_client.logout()
        return {
            'statusCode': 201,
            'body': json.dumps({
                "message": f"Usuario con tenantID {tenant_id} fue creado exitosamente."
            })
        }

    except Exception as e:
        logger.error("Unexpected Error: %s", str(e))
        api_client.logout()
        return {
            'statusCode': 500,
            'body': json.dumps({
                "error": "Lambda Handler: Error inesperado.",
                "details": str(e)
            })
        }