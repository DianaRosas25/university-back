import json
import os
import psycopg2

def lambda_handler(event, context):
    try:
        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            database=os.environ['DB_NAME'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            port=os.environ['DB_PORT']
        )
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, chain_name, domain FROM mdl_cadenas_cohortes WHERE active = TRUE;
        """)

        results = cursor.fetchall()
        authorized_chains = [{
            "id": row[0],
            "chain_name": row[1],
            "domain": row[2]
        } for row in results]

        return {
            "statusCode": 200,
            "body": authorized_chains,
            "headers": {"Content-Type": "application/json"}
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": {"Content-Type": "application/json"}
        }

    finally:
        cursor.close()
        conn.close()