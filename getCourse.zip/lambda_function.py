import json
import psycopg2
import os
import re
import boto3

def clean_html(value):
    return re.sub(r'<.*?>', '', value) if value else "No disponible"

def get_s3_image_url(course_id, bucket_name):
    s3_client = boto3.client('s3')
    image_key = f"portada_curso_{course_id}.png"
    try:
        s3_client.head_object(Bucket=bucket_name, Key=image_key)
        return f"https://{bucket_name}.s3.amazonaws.com/{image_key}"
    except s3_client.exceptions.ClientError:
        return "Imagen no disponible"

def remove_img_tags(html):
    return re.sub(r'<img[^>]*>', '', html or '')

def extract_numeric_cost(value):
    try:
        num = float(re.findall(r'\d+(?:\.\d+)?', value or '')[0])
        return str(int(num)) if num.is_integer() else str(num)
    except (IndexError, ValueError, TypeError):
        return "0"

def format_duracion(value):
    try:
        num = re.findall(r'\d+(?:\.\d+)?', value or '')[0]
        return f"{num} hrs"
    except (IndexError, TypeError):
        return "0 hrs"

def lambda_handler(event, context):
    try:
        s3_bucket_name = os.environ['S3_BUCKET_NAME']
        query_params = event.get('queryStringParameters') or {}
        ids = query_params.get('ids', '')
        if not ids:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': 'El parámetro "ids" es obligatorio.'})
            }

        course_ids = [int(cid.strip()) for cid in ids.split(',') if cid.strip().isdigit()]
        if not course_ids:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': 'No se proporcionaron IDs válidos.'})
            }

        conn = psycopg2.connect(
            host=os.environ['DB_HOST'],
            port=os.environ['DB_PORT'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )
        cursor = conn.cursor()

        format_ids = ','.join(['%s'] * len(course_ids))
        base_query = f"""
            SELECT c.id, c.fullname, c.shortname, c.summary, cat.name AS category_name
            FROM mdl_course c
            LEFT JOIN mdl_course_categories cat ON c.category = cat.id
            WHERE c.id IN ({format_ids})
        """
        cursor.execute(base_query, course_ids)
        courses = cursor.fetchall()

        # Obtener mapeo de campos personalizados
        cursor.execute("SELECT cf.id, cf.shortname FROM mdl_customfield_field cf")
        customfields = {row[0]: row[1] for row in cursor.fetchall()}

        # Obtener datos personalizados
        cursor.execute("""
            SELECT cd.instanceid, cf.shortname, cd.value
            FROM mdl_customfield_data cd
            INNER JOIN mdl_customfield_field cf ON cd.fieldid = cf.id
        """)
        customfield_data = cursor.fetchall()

        customfield_mapping = {}
        for instanceid, shortname, value in customfield_data:
            if instanceid not in customfield_mapping:
                customfield_mapping[instanceid] = {}
            customfield_mapping[instanceid][shortname] = value

        # Obtener idiomas por curso (fieldid = 12)
        idioma_inverse_map = {1: 'ES', 2: 'EN', 3: 'PT'}
        cursor.execute("""
            SELECT instanceid, intvalue
            FROM mdl_customfield_data
            WHERE fieldid = 12
        """)
        idioma_data = cursor.fetchall()
        idioma_por_curso = {row[0]: idioma_inverse_map.get(row[1], "No disponible") for row in idioma_data}

        # Construir respuesta
        catalogo_cursos = []
        for course in courses:
            course_id, fullname, shortname, summary, category_name = course
            custom_data = customfield_mapping.get(course_id, {})
            profile_image = get_s3_image_url(course_id, s3_bucket_name)

            course_data = {
                "profileCodeCurso": shortname,
                "profileNameCurso": clean_html(fullname),
                "profileDescriptionCurso": remove_img_tags(summary),
                "profileIdCurso": course_id,
                "profileCategoria": category_name,
                "profileIdioma": idioma_por_curso.get(course_id, "No disponible"),
                "profileCosto": extract_numeric_cost(custom_data.get("tool_costo", None)),
                "profileDuracion": format_duracion(custom_data.get("tool_duracion", None)),
                "profileObjetivos": custom_data.get("tool_objetivo", "No disponible"),
                "profileObjetosAprendizaje": custom_data.get("tool_objetos", "No disponible"),
                "profileTemario": custom_data.get("tool_temario", "No disponible"),
                "profileRequerimientosPrevios": custom_data.get("tool_requerimintos_previos", "No disponible"),
                "profileRequerimientosEquipo": custom_data.get("tool_requerimientos_equipo", "No disponible"),
                "profileCursosRelacionados": custom_data.get("tool_curso_adicional", "No disponible"),
                "profileImage": profile_image
            }

            catalogo_cursos.append(course_data)

        cursor.close()
        conn.close()

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({"catalogo": catalogo_cursos})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Error procesando la solicitud.', 'details': str(e)})
        }

