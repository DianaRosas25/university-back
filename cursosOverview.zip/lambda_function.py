import json
import os
import psycopg2
import psycopg2.extras

# Lista fija de cursos
COURSES = [
    "Overview StackUp University",
    "Overview StackUp Revenue Management",
    "Overview StackUp Business Analytics",
    "Overview StackUp Front2Go",
    "Overview StackUp Flowlink",
    "Overview StackUp CRM",
    "Overview StackUp Brand Site",
    "Overview StackUp POS2Go",
    "Overview StackUp Panel de control"
]

# Mapeo del idioma
IDIOMA_MAP = {
    1: "Español",
    2: "Inglés",
    3: "Portugués"
}

def lambda_handler(event, context):
    try:
        # Validar método HTTP
        if event.get('httpMethod') != 'GET':
            return {
                'statusCode': 405,
                'body': json.dumps({
                    'error': 'Método no permitido. Solo GET permitido.'
                })
            }

        # Conexión con PostgreSQL usando psycopg2
        connection = psycopg2.connect(
            host=os.environ['DB_HOST'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            dbname=os.environ['DB_NAME']
        )

        cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

        try:
            # Consulta SQL usando psycopg2 (PostgreSQL)
            sql_query = """
                SELECT c.id, c.fullname, cd.intvalue AS idioma
                FROM mdl_course c
                INNER JOIN mdl_customfield_data cd ON cd.instanceid = c.id
                WHERE cd.fieldid = 12 AND c.fullname = ANY(%s)
            """

            cursor.execute(sql_query, (COURSES,))
            results = cursor.fetchall()

            grouped_courses = {name: [] for name in COURSES}

            for row in results:
                idioma_num = row['idioma']
                idioma_texto = IDIOMA_MAP.get(idioma_num, 'Desconocido')

                grouped_courses[row['fullname']].append({
                    'course_id': row['id'],
                    'course_name': row['fullname'],
                    'idioma': idioma_texto
                })

            # Limpiar entradas sin resultados
            grouped_courses = {k: v for k, v in grouped_courses.items() if v}

            return {
                'statusCode': 200,
                'body': json.dumps({
                    'courses': grouped_courses
                })
            }

        finally:
            cursor.close()
            connection.close()

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Error procesando la solicitud.',
                'details': str(e)
            })
        }
