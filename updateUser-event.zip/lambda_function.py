import json
import os
import requests
import random
import string
import logging
import time
from datetime import datetime
import unicodedata
from psycopg2 import pool

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def normalize_string(string):
    text = ''.join(
        c for c in unicodedata.normalize('NFKD', string) 
        if unicodedata.category(c) != 'Mn'
    )
    return ''.join(e for e in text if e.isalnum()).lower()

db_connector = None
def get_db_connector():
    global db_connector
    if db_connector is None:
        import psycopg2
        db_connector = psycopg2
    return db_connector

global_moodle_session = requests.Session()
global_moodle_session.mount('https://', requests.adapters.HTTPAdapter(
    max_retries=3,
    pool_connections=10,
    pool_maxsize=10
))

class MoodleClient:
    def __init__(self, token, session=global_moodle_session):
        self.token = token
        self.session = session
        self.base_url = os.environ.get('MOODLE_URL')
        self.endpoint = f"{self.base_url}/webservice/rest/server.php"

    def get_user_by_email(self, email, retries=3, backoff_in_seconds=1):
        payload = {
            'wstoken': self.token,
            'wsfunction': 'core_user_get_users',
            'moodlewsrestformat': 'json',
            'criteria[0][key]': 'email',
            'criteria[0][value]': email
        }
        for attempt in range(retries):
            try:
                response = self.session.post(self.endpoint, data=payload, verify=False, timeout=30)
                if response.status_code == 200:
                    data = response.json()
                    if 'users' in data and len(data['users']) > 0:
                        return data['users'][0]
                return None
            except Exception as e:
                logger.warning(f"Error intentando obtener usuario: {e}, intento {attempt+1}/{retries}")
                time.sleep(backoff_in_seconds * (2 ** attempt))
        return None

class DBManager:
    def __init__(self):
        self.pool = None

    def get_pool(self):
        if self.pool is None:
            psycopg2 = get_db_connector()
            self.pool = psycopg2.pool.SimpleConnectionPool(
                minconn=1,
                maxconn=5,
                host=os.environ['DB_HOST'],
                port=os.environ['DB_PORT'],
                user=os.environ['DB_USER'],
                password=os.environ['DB_PASS'],
                dbname=os.environ['DB_NAME']
            )
        return self.pool

    def get_connection(self):
        return self.get_pool().getconn()

    def release_connection(self, conn):
        self.get_pool().putconn(conn)

    def update_panel_data_by_user_id_panel(self, user_id_panel, user_id, tenant_id, hotel_data, modules, role, retries=3, backoff_in_seconds=1):
        for attempt in range(retries):
            conn = self.get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        UPDATE mdl_panel_datos
                        SET 
                            id_tenant = %s,
                            id_marca = %s,
                            id_hotel = %s,
                            clave = %s,
                            id_region = %s,
                            modulos = %s,
                            role = %s,
                            user_id = %s
                        WHERE user_id_panel = %s
                    """, (
                        tenant_id,
                        hotel_data.get("id_marca"),
                        hotel_data.get("id_hotel"),
                        hotel_data.get("clave"),
                        hotel_data.get("id_region"),
                        modules,
                        role,
                        user_id,
                        user_id_panel
                    ))
                    conn.commit()
                    return True
            except Exception as e:
                logger.warning(f"Error intentando actualizar BD: {e}, intento {attempt+1}/{retries}")
                time.sleep(backoff_in_seconds * (2 ** attempt))
            finally:
                self.release_connection(conn)
        return False

moodle_client = MoodleClient(os.environ['MOODLE_TOKEN'])
db_manager = DBManager()

def map_profile_to_role(profile_str):
    profile_num = profile_str.split('_')[-1]
    if profile_num == '5':
        return 'user'
    elif profile_num == '4':
        return 'admin'
    return 'unknown'

def lambda_handler(event, context):
    try:
        logger.info("Evento recibido: %s", json.dumps(event))

        if event.get("detail-type") != "USERUpdate":
            return {"statusCode": 400, "body": "Evento no válido"}

        user = event["detail"]["data"]
        tenant_id = user.get("tenantId")
        user_panel_id = user.get("id")
        email = user.get("email")
        first_name = user.get("firstName")
        last_name = user.get("lastName")
        phone = user.get("phone")
        applications = user.get("userApplications", [])

        university_app = next((app for app in applications if app["applicationId"] == 2), None)
        if not university_app:
            return {"statusCode": 403, "body": "Usuario sin acceso a University"}

        moodle_user = moodle_client.get_user_by_email(email)
        if not moodle_user:
            return {"statusCode": 404, "body": "Usuario no encontrado en Moodle"}

        moodle_user_id = moodle_user["id"]

        update_payload = {
            'wstoken': moodle_client.token,
            'wsfunction': 'core_user_update_users',
            'moodlewsrestformat': 'json',
            'users[0][id]': moodle_user_id,
            'users[0][firstname]': first_name,
            'users[0][lastname]': last_name,
            'users[0][email]': email,
            'users[0][phone1]': phone
        }

        response = moodle_client.session.post(moodle_client.endpoint, data=update_payload, verify=False, timeout=30)

        if response.status_code != 200 or ('exception' in response.json() if response.content else False):
            return {"statusCode": 500, "body": "Error al actualizar usuario en Moodle"}
        
        logger.info("Actualizado con éxito.")

        return {"statusCode": 200, "body": "Usuario actualizado correctamente"}

    except Exception as e:
        logger.exception("Error inesperado en USER_UPDATED")
        return {"statusCode": 500, "body": f"Error inesperado: {str(e)}"}
