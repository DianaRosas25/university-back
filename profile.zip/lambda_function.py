import json
import psycopg2
import os

def lambda_handler(event, context):
    # Conexión directa a la base de datos PostgreSQL en AWS
    conn = psycopg2.connect(
        host=os.environ['DB_HOST'],
        port=os.environ['DB_PORT'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASS'],
        dbname=os.environ['DB_NAME']
    )

    cursor = conn.cursor()

    # Query para obtener solo los roles que interesan
    cursor.execute("""
        SELECT name, shortname, id, description
        FROM mdl_role
        WHERE name IN ('SuperAdmin', 'Administrador', 'Usuario', 'Soporte')
    """)

    # Recuperar todos los resultados
    rows = cursor.fetchall()

    # Crear la estructura JSON como una lista de perfiles
    profiles = []
    for row in rows:
        # Definir el valor de visible_for_user basado en el nombre del perfil
        if row[0] == "SuperAdmin" or row[0] == "Soporte":
            visible_for_user = 0
        else:
            visible_for_user = 1

        profile = {
            "profileAssig": "eLearning",  # Valor estático
            "profileName": row[0],  # Columna name de mdl_role
            "profileRole": row[1],  # Columna shortname de mdl_role
            "profileId": "LMS_Perfil_" + str(row[2]),
            "profileDescription": row[3],  # Columna description de mdl_role
            "visible_for_user": visible_for_user  # Nuevo campo agregado
        }
        profiles.append(profile)

    # Cerrar la conexión
    cursor.close()
    conn.close()

    # Crear el cuerpo de la respuesta con el catálogo de roles
    response_body = {
        "profiles": profiles
    }

    # Crear la respuesta final
    response = {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': response_body  # Serializar el diccionario como JSON
    }

    # Retornar la respuesta completa
    return response
